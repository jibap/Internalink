/*
 * File : assets/linky.js
 */
( function( $ ) {
  /**
   * @param $scope The Widget wrapper element as a jQuery element
   * @param $ The jQuery alias
   */
   
  // Make sure you run this code under Elementor.
  $( window ).on( 'elementor/frontend/init', function() {
    // ON SPECIFIC BUTTON EVENT
    // elementor.channels.editor.on('linky:editor:shortcode', function( element) {
    //   // console.log(element);
    // });
    // ON WIDGET OPENING
    // elementor.hooks.addAction('panel/open_editor/widget/linky',function( panel, model, view ) {
    //     // Do what you want !
    // });
  } );
} )( jQuery );
