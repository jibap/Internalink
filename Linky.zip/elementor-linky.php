<?php
/**
/**
 * Plugin Name: Elementor Linky
 * Description: Elementor plugin to include internal post link  or external link with title, image and excerpt 
 * Plugin URI:  https://github.com/jibap/Linky
 * Version:     1.0.0
 * Author:      Jibap
 * Author URI:  https://informapic.fr
 * Text Domain: elementor-linky
 * Elementor tested up to: 3.7.0
 */
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * Main Elementor Linky Class
 *
 * The init class that runs the Elementor Linky plugin.
 * Intended To make sure that the plugin's minimum requirements are met.
 *
 * You should only modify the constants to match your plugin's needs.
 *
 * Any custom code should go inside Plugin Class in the plugin.php file.
 * @since 1.0.0
 */
final class Elementor_Linky {
 
  /**
   * Plugin Version
   *
   * @since 1.0.0
   * @var string The plugin version.
   */
  const VERSION = '1.0.0';
 
  /**
   * Minimum Elementor Version
   *
   * @since 1.0.0
   * @var string Minimum Elementor version required to run the plugin.
   */
  const MINIMUM_ELEMENTOR_VERSION = '2.0.0';
 
  /**
   * Minimum PHP Version
   *
   * @since 1.0.0
   * @var string Minimum PHP version required to run the plugin.
   */
  const MINIMUM_PHP_VERSION = '7.0';
 
  /**
   * Constructor
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
 
    // Load translation
    add_action( 'init', array( $this, 'i18n' ) );
 
    // Init Plugin
    add_action( 'plugins_loaded', array( $this, 'init' ) );
  }
 
  /**
   * Load Textdomain
   *
   * Load plugin localization files.
   * Fired by `init` action hook.
   *
   * @since 1.2.0
   * @access public
   */
  public function i18n() {
    load_plugin_textdomain( 'elementor-linky' );
  }
 
  /**
   * Initialize the plugin
   *
   * Validates that Elementor is already loaded.
   * Checks for basic plugin requirements, if one check fail don't continue,
   * if all check have passed include the plugin class.
   *
   * Fired by `plugins_loaded` action hook.
   *
   * @since 1.2.0
   * @access public
   */
  public function init() {
 
    // Check if Elementor installed and activated
    if ( ! did_action( 'elementor/loaded' ) ) {
      add_action( 'admin_notices', array( $this, 'admin_notice_missing_main_plugin' ) );
      return;
    }
 
    // Check for required Elementor version
    if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
      add_action( 'admin_notices', array( $this, 'admin_notice_minimum_elementor_version' ) );
      return;
    }
 
    // Check for required PHP version
    if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
      add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
      return;
    }
 
    // Once we get here, We have passed all validation checks so we can safely include our plugin
    require_once( 'plugin.php' );
  }
 
  /**
   * Admin notice
   *
   * Warning when the site doesn't have Elementor installed or activated.
   *
   * @since 1.0.0
   * @access public
   */
  public function admin_notice_missing_main_plugin() {
    if ( isset( $_GET['activate'] ) ) {
      unset( $_GET['activate'] );
    }
 
    $message = sprintf(
      /* translators: 1: Plugin name 2: Elementor */
      esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'elementor-linky' ),
      '<strong>' . esc_html__( 'Elementor Linky', 'elementor-linky' ) . '</strong>',
      '<strong>' . esc_html__( 'Elementor', 'elementor-linky' ) . '</strong>'
    );
 
    printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
  }
 
  /**
   * Admin notice
   *
   * Warning when the site doesn't have a minimum required Elementor version.
   *
   * @since 1.0.0
   * @access public
   */
  public function admin_notice_minimum_elementor_version() {
    if ( isset( $_GET['activate'] ) ) {
      unset( $_GET['activate'] );
    }
 
    $message = sprintf(
      /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
      esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-linky' ),
      '<strong>' . esc_html__( 'Elementor Linky', 'elementor-linky' ) . '</strong>',
      '<strong>' . esc_html__( 'Elementor', 'elementor-linky' ) . '</strong>',
      self::MINIMUM_ELEMENTOR_VERSION
    );
 
    printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
  }
 
  /**
   * Admin notice
   *
   * Warning when the site doesn't have a minimum required PHP version.
   *
   * @since 1.0.0
   * @access public
   */
  public function admin_notice_minimum_php_version() {
    if ( isset( $_GET['activate'] ) ) {
      unset( $_GET['activate'] );
    }
 
    $message = sprintf(
      /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
      esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-linky' ),
      '<strong>' . esc_html__( 'Elementor Linky', 'elementor-linky' ) . '</strong>',
      '<strong>' . esc_html__( 'PHP', 'elementor-linky' ) . '</strong>',
      self::MINIMUM_PHP_VERSION
    );
 
    printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
  }
}
 
// Instantiate Elementor_Linky.
new Elementor_Linky();

// Create a shortcode to render HTML (inverse is not working... (call a widget into shortcode))
function linky_shortcode($atts) {
        extract(shortcode_atts(array(
            'post_id' => '',
            'url' => '',
            'title'=>'',
            'excerpt'=>'',
            'thumbnail' => '',
            'target' => '_top',
        ), $atts));


        // INIT PARAMS
        $url =  $atts['url'];
        $excerpt = $atts['excerpt'];
        $title = $atts['title'];
        $thumbnail = $atts['thumbnail'];
        $target= $atts['target'];

        // CHECK LINK
        if (empty($atts['post_id']) && empty($url)){
            // NI POST_ID, NI URL
            return '<strong>LINKY : Aucun lien renseigné !</strong>';
        }
        
        // TRAITEMENT SPECIFIQUE POUR LES IMAGES
        if( ! empty( $thumbnail )){
          // IMAGE INTERNE ?
          $thumbnail_id = attachment_url_to_postid($thumbnail);
          if( ! empty($thumbnail_id)){
            $thumbnail = wp_get_attachment_image($thumbnail_id);
          }else{
            // HTML SPECIFIQUE POUR IMAGE EXTERNE
            $thumbnail = '<img src="'. $thumbnail .'" loading="lazy" style="max-height: 150px;">';
          }
        }

        // CHECK FOR POST ID OR URL ?
        if ( ! empty( $atts['post_id'] ) ) {
          $post_id = $atts['post_id'];
          // RETRIEVE URL
          $url = get_permalink($post_id);
        }else{
          // CHECK FOR INTERNAL CONTENT ?
          $post_id = url_to_postid($url);
        }

        // GET INFOS FOR INTERNAL POST
        if( ! empty ($post_id)){
          // GET POST to check if exists
          $post = get_post($post_id);
          if($post){          
            // PAGE ou ARTICLE SEULEMENT !
            if($post->post_type !== "post" && $post->post_type !== "page")  return '<strong>LINKY : Lien renseigné incorrect : page ou article seulement !</strong>';

            // IMAGE
            if (empty( $thumbnail )) {
              $thumbnail = wp_get_attachment_image( get_post_thumbnail_id($post_id));
            }
            // TITRE
            if (empty( $title ) ) {
              $title = $post->post_title;
            }
            // EXTRAIT
            if (empty( $excerpt ) ) {
              $excerpt = get_the_excerpt($post_id);
            }
          }else{
            return '<strong>LINKY : Lien renseigné incorrect : POST introuvable !</strong>';
          }
        }else{
          // EMPTY OR BAD POST ID, CHECK FOR URL VALID ?
          if (filter_var($url, FILTER_VALIDATE_URL) === false) {
            return '<strong>LINKY : Lien renseigné incorrect : URL introuvable !</strong>';
          }
        }

        $data = '<div class="linky-container"><a href="'.$url.'" target="'.$target.'" class="linky" ></a><div class="linky-layout-zone-side"><div class="linky-block-2 linky-image">'.$thumbnail.'</div></div><div class="linky-layout-zone-main"><div class="linky-block-0 linky-title">'.$title.'</div><div class="linky-block-1 linky-summary">'.$excerpt.'</div></div></div>';
        return $data;
    }
   
function shortcodes_init(){
  add_shortcode( 'linky', 'linky_shortcode' );
}
add_action('init', 'shortcodes_init');