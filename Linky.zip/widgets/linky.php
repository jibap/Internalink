<?php
namespace ElementorLinky\Widgets;
 
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
 
/**
 * @since 1.1.0
 * File : widgets/linky.php
 */
class Linky extends Widget_Base {

 
  /**
   * Retrieve the widget name.
   *
   * @since 1.1.0
   *
   * @access public
   *
   * @return string Widget name.
   */
  public function get_name() {
    return 'linky';
  }
 
  /**
   * Retrieve the widget title.
   *
   * @since 1.1.0
   *
   * @access public
   *
   * @return string Widget title.
   */
  public function get_title() {
    return __( 'Linky', 'elementor-linky' );
  }
 
  /**
   * Retrieve the widget icon.
   *
   * @since 1.1.0
   *
   * @access public
   *
   * @return string Widget icon.
   */
  public function get_icon() {
    return 'eicon-button';
  }
 
  /**
   * Retrieve the list of categories the widget belongs to.
   *
   * Used to determine where to display the widget in the editor.
   *
   * Note that currently Elementor supports only one category.
   * When multiple categories passed, Elementor uses the first one.
   *
   * @since 1.1.0
   *
   * @access public
   *
   * @return array Widget categories.
   */
  public function get_categories() {
    return [ 'general' ];
  }
 
  /**
   * Register the widget controls.
   *
   * Adds different input fields to allow the user to change and customize the widget settings.
   *
   * @since 1.1.0
   *
   * @access protected
   */
  protected function _register_controls() {
    $this->start_controls_section(
      'section_content',
      [
        'label' => __( 'Lien', 'elementor-linky' ),
      ]
    );

    // VERSION BASIQUE 

    // $options = [];
    // $posts = get_posts(['numberposts' => -1, 'post_type' => array('page','post')]);
    // foreach ( $posts as $post ) {
    //   $date = date_create($post->post_date);
    //   $date = date_format($date,"m/Y");
    //   $options[ $post->ID ] = '(#' . $post->ID .') '. $post->post_title. ' - '. $date ;
    // }
    // $this->add_control(
    //     'post_id',
    //     [
    //         'label' => esc_html__( 'Article interne', 'elementor-linky' ),
    //         'type' => Controls_Manager::SELECT2,
    //         'label_block' => true,
    //         'multiple' => false,
    //         'options' => $options,
    //     ]
    // ); 

    $this->add_control(
      'link',
      [
        'label' => esc_html__( 'URL / Article / Page', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::URL,
        'placeholder' => esc_html__( 'https://adresse.ext | Saisir une recherche', 'elementor-linky' ),
        'options' => [ 'url', 'is_external' ],
        'default' => [
          'url' => '',
          'is_external' => false
        ],
        'label_block' => true,
      ]
    );

    $this->add_control(
      'custom_switcher',
      [
        'label' => esc_html__( 'Attributs personnalisés :', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Oui', 'elementor-linky' ),
        'label_off' => esc_html__( 'Non', 'elementor-linky' ),
        'return_value' => '1',
        'default' => '0',
        'description' => esc_html__( 'Surcharge les attributs (Titre, Extrait, Image)', 'elementor-linky' ),
      ]
    );

    $this->add_control(
      'more_options',
      [
        'label' => esc_html__( 'Attributs personnalisés ?', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
        'condition' => [
          'custom_switcher' => '1',
        ]
      ]
    );

    $this->add_control(
      'custom_title',
      [
        'label' => esc_html__( 'Titre :', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'default' => esc_html__( '', 'elementor-linky' ),
        'label_block' => true,
        'condition' => [
          'custom_switcher' => '1',
        ],
      ]
    );

    $this->add_control(
      'custom_excerpt',
      [
        'label' => esc_html__( 'Extrait :', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::TEXTAREA,
        'rows' => 5,
        'default' => esc_html__( '', 'elementor-linky' ),
        'condition' => [
          'custom_switcher' => '1',
        ],
      ]
    );

    $this->add_control(
      'custom_image',
      [
        'label' => __( 'Image :', 'elementor-linky' ),
        'type' => Controls_Manager::MEDIA,
        'default' => [],
        'condition' => [
          'custom_switcher' => '1',
        ],
      ]
    );
    $this->add_control(
      'syntax_header',
      [
        'label' => esc_html__( 'Syntaxe du shortcode :', 'elementor-linky' ),
        'type' => \Elementor\Controls_Manager::HEADING,
        'separator' => 'before',
      ]
    );

    $this->add_control(
      'syntax',
      [
        'type' => \Elementor\Controls_Manager::RAW_HTML,
        'raw' => esc_html__( '[linky post_id="#" (url="" title="" thumbnail="" excerpt="" target="_blank")]', 'elementor-linky' ),
      ]
    );
    // $this->add_control(
    //   'generate_shortcode',
    //   [
    //     'type' => \Elementor\Controls_Manager::BUTTON,
    //     'separator' => 'before',
    //     'button_type' => 'success',
    //     'text' => esc_html__( '  Afficher le shortcode  ', 'elementor-linky' ),
    //     'event' => 'linky:editor:shortcode',
    //     'description' => '',
    //   ]
    // );
 
    $this->end_controls_section();
  }
 
  /**
   * Render the widget output on the frontend.
   *
   * Written in PHP and used to generate the final HTML.
   *
   * @since 1.1.0
   *
   * @access protected
   */
  protected function render() {
    $settings = $this->get_settings_for_display();

    // LINK 
    if ( ! empty( $settings['link']['url'] ) ) {
      // TRANSPOSE SETTINGS
      $params['url'] = $settings['link']['url'];
      $params['title'] = $settings['custom_title'];
      $params['excerpt'] = $settings['custom_excerpt'];
      $params['thumbnail'] = $settings['custom_image']['url'];
      if( $settings['link']['is_external'] ){
        $params['target'] = '_blank';
      }

      // GET THE SHORTCODE HTML
      $data = linky_shortcode($params);
    }else{
      $data = '<strong>LINKY : Lien non renseigné...</strong>'; 
    }
    echo $data;
  }
 
  /**
   * Render the widget output in the editor.
   *
   * Written as a Backbone JavaScript template and used to generate the live preview.
   *
   * @since 1.1.0
   *
   * @access protected
   */
  protected function content_template() {
    // Nothing special ! 
  }
}